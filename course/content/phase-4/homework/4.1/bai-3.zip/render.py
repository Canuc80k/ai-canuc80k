import json,sys
from pathlib import Path
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
case=Path(sys.argv[1]); data=json.loads((case/'input.json').read_text(encoding='utf-8')); result=json.loads(Path(sys.argv[2]).read_text(encoding='utf-8'))
fig,axes=plt.subplots(3,4,figsize=(8,6))
for axis,name,label in zip(axes.flat,data['image_names'][:12],result['predictions'][:12]):
    axis.imshow(Image.open(case/name),cmap='gray_r',vmin=0,vmax=240); axis.set_title('Prediction '+str(label)); axis.axis('off')
plt.tight_layout(); plt.savefig('view.png'); plt.close('all')
