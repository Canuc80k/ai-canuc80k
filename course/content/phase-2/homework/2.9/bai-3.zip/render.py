import json,sys,csv
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
with (Path(sys.argv[1])/'test.csv').open() as f: raw=np.array([[float(v) for v in row.values()] for row in csv.DictReader(f)])
rec=np.array(json.loads(Path(sys.argv[2]).read_text())['reconstructed'])
fig,axes=plt.subplots(2,6,figsize=(8,3))
for i in range(6):
    for row,values in ((0,raw),(1,rec)):
        axes[row,i].imshow(values[i].reshape(8,8),cmap='gray',vmin=0,vmax=16); axes[row,i].axis('off')
fig.suptitle('Real UCI digits (top), PCA reconstruction (bottom)'); plt.tight_layout(); plt.savefig('view.png'); plt.close('all')
