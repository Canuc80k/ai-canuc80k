import json,sys,numpy as np
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
case=Path(sys.argv[1]); data=json.loads((case/'input.json').read_text(encoding='utf-8')); result=json.loads(Path(sys.argv[2]).read_text(encoding='utf-8')); images=np.array(data['test_images'])[:,0]; masks=np.array(result['predictions']).reshape(3,8,8)
fig,axes=plt.subplots(2,3,figsize=(8,5))
for j in range(3):
    axes[0,j].imshow(images[j],cmap='inferno',vmin=0,vmax=1); axes[1,j].imshow(masks[j],cmap='gray',vmin=0,vmax=1); axes[0,j].set_title('Owned thermal toy'); axes[1,j].set_title('Actual predicted pixels'); axes[0,j].axis('off'); axes[1,j].axis('off')
plt.tight_layout(); plt.savefig('view.png'); plt.close('all')
