import json,sys,numpy as np,pandas as pd
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
case=Path(sys.argv[1]); frame=pd.read_csv(case/'test.csv'); images=frame[['p'+str(i) for i in range(64)]].to_numpy().reshape(-1,8,8); result=json.loads(Path(sys.argv[2]).read_text(encoding='utf-8')); fig,axes=plt.subplots(3,4,figsize=(8,6))
for axis,image,label in zip(axes.flat,images[:12],result['predictions'][:12]):
    axis.imshow(image,cmap='gray_r',vmin=0,vmax=16); axis.set_title('Fresh reload '+str(label)); axis.axis('off')
plt.tight_layout(); plt.savefig('view.png'); plt.close('all')
