import json,sys,numpy as np
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
result=json.loads(Path(sys.argv[2]).read_text(encoding='utf-8')); image=np.array(result['output'])[0,0]
plt.imshow(image,cmap='coolwarm'); plt.colorbar(); plt.title('Actual first output channel'); plt.tight_layout(); plt.savefig('view.png'); plt.close('all')
