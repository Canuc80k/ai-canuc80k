import json
import sys


def refreshList(L):
    # Sửa trực tiếp list L. Không cần return.
    raise NotImplementedError


def solve(data):
    refreshList(data)
    return data


if __name__ == "__main__":
    data = json.load(sys.stdin)
    print(json.dumps(solve(data)))
