import csv
import io
import json
import sys


def solve(data):
    # Viết lời giải ở đây.
    raise NotImplementedError


if __name__ == "__main__":
    data = json.load(sys.stdin)
    sys.stdout.write(solve(data))
