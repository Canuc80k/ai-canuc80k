"""Chạy: python starter.py   (đọc inputs/, ghi output/ và output/submission.zip)."""
import csv
import json
import zipfile
from pathlib import Path


def solve(data, case_dir):
    # data: nội dung input.json; case_dir: thư mục của test (chứa các tệp CSV nếu có).
    raise NotImplementedError


def write_answer(target, value):
    with target.open("w", encoding="utf-8", newline="") as stream:
        stream.write(value)

if __name__ == "__main__":
    root = Path(__file__).resolve().parent
    output = root / "output"
    output.mkdir(exist_ok=True)
    names = []
    for case_dir in sorted(p for p in (root / "inputs").iterdir() if p.is_dir()):
        data = json.loads((case_dir / "input.json").read_text(encoding="utf-8"))
        target = output / (case_dir.name + ".csv")
        write_answer(target, solve(data, case_dir))
        names.append(target)
    with zipfile.ZipFile(output / "submission.zip", "w", zipfile.ZIP_DEFLATED) as archive:
        for target in names:
            archive.write(target, target.name)
    print("Đã tạo output/submission.zip gồm", len(names), "tệp")
