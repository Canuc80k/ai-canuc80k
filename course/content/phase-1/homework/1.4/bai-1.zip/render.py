import json,sys
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
result=json.loads(Path(sys.argv[2]).read_text(encoding='utf-8'))
if 'features' in result:
    array=np.asarray(result['features'])
    plt.imshow(array,aspect='auto',cmap='coolwarm'); plt.colorbar(label='Transformed value')
    plt.xlabel('Feature index (see feature_names if given)'); plt.ylabel('Test row')
else:
    array=np.asarray(result['fold_means'])
    for j in range(array.shape[1]): plt.plot(range(5),array[:,j],marker='o',label='Feature '+str(j))
    plt.xlabel('Held-out fold'); plt.ylabel('Mean of complementary TRAIN'); plt.legend()
plt.tight_layout(); plt.savefig('view.png',dpi=120); plt.close('all')
