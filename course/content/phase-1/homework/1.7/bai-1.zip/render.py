import json,sys
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
result=json.loads(Path(sys.argv[2]).read_text(encoding='utf-8'))
if 'scores' in result:
    plt.plot([row['k'] for row in result['scores']],[row['mean_cv_f1'] for row in result['scores']],marker='o')
    plt.xlabel('k'); plt.ylabel('Development CV F1 (NOT outer test)')
elif 'outer_f1' in result:
    plt.bar(range(3),result['outer_f1']); plt.ylim(0,1); plt.xlabel('Outer held fold'); plt.ylabel('F1 after INNER selection')
else:
    plt.bar(['CV only','With refit'],[result['cv_fits'],result['total_fits']]); plt.ylabel('Model fit count')
plt.tight_layout(); plt.savefig('view.png',dpi=120); plt.close('all')
