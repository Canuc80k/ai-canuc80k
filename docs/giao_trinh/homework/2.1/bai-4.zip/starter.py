"""Chạy: python starter.py   (đọc inputs/, ghi output/ và output/submission.zip)."""
import csv
import json
import zipfile
from pathlib import Path


import numpy as np


def my_fun_derivative(X, y, theta):
    # Không vòng lặp, không @, không .T, không np.linalg.
    raise NotImplementedError


def solve(data, case_dir):
    X, y, theta = np.asarray(data["X"]), np.asarray(data["y"]), np.asarray(data["theta"])
    return {"gradient": my_fun_derivative(X, y, theta).tolist()}


def write_answer(target, value):
    target.write_text(json.dumps(value, ensure_ascii=False) + "\n", encoding="utf-8")

if __name__ == "__main__":
    root = Path(__file__).resolve().parent
    output = root / "output"
    output.mkdir(exist_ok=True)
    names = []
    for case_dir in sorted(p for p in (root / "inputs").iterdir() if p.is_dir()):
        data = json.loads((case_dir / "input.json").read_text(encoding="utf-8"))
        target = output / (case_dir.name + ".json")
        write_answer(target, solve(data, case_dir))
        names.append(target)
    with zipfile.ZipFile(output / "submission.zip", "w", zipfile.ZIP_DEFLATED) as archive:
        for target in names:
            archive.write(target, target.name)
    print("Đã tạo output/submission.zip gồm", len(names), "tệp")
