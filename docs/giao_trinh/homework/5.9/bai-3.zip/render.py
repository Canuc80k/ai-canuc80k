import json,sys,numpy as np
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
result=json.loads(Path(sys.argv[2]).read_text(encoding='utf-8')); fig,axes=plt.subplots(1,2,figsize=(8,3)); axes[0].imshow(np.array(result['saliency']),cmap='coolwarm'); axes[0].set_title('Signed input gradient'); axes[1].imshow(np.array(result['gradcam']),cmap='inferno'); axes[1].set_title('Raw Grad-CAM'); plt.tight_layout(); plt.savefig('view.png'); plt.close('all')
