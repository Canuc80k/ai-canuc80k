import json,sys
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
result=json.loads(Path(sys.argv[2]).read_text(encoding='utf-8'))
if 'ap' in result:
    plt.bar(range(len(result['ap'])),result['ap']); plt.ylim(0,1); plt.xlabel('Query in input order'); plt.ylabel('AP@k')
elif 'mae' in result:
    plt.bar(['MAE','RMSE'],[result['mae'],result['rmse']]); plt.ylabel('Target units (MSE has SQUARED units)')
else:
    plt.bar(['MAPE ratio'],[result['ratio']]); plt.ylabel('Ratio NOT percent'); plt.title('Zero targets: '+str(result['zero_targets']))
plt.tight_layout(); plt.savefig('view.png',dpi=120); plt.close('all')
