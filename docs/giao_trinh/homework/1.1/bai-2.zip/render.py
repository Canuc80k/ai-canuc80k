import json
import sys
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
case = Path(sys.argv[1])
data = json.loads((case/'input.json').read_text(encoding='utf-8'))
pred = json.loads(Path(sys.argv[2]).read_text(encoding='utf-8'))['predictions']
test = pd.read_csv(case/'test.csv',dtype={'id':str})
if data['dataset']=='iris':
    plt.scatter(test['f2'],test['f3'],c=pred,cmap='viridis',vmin=0,vmax=2)
    plt.xlabel('Petal length (cm)'); plt.ylabel('Petal width (cm)')
    plt.title('Predicted species')
elif data['dataset']=='digits':
    fig,axes=plt.subplots(3,4,figsize=(7,5))
    for i,ax in enumerate(axes.flat):
        ax.imshow(test[data['feature_columns']].iloc[i].to_numpy().reshape(8,8),cmap='gray_r',vmin=0,vmax=16)
        ax.set_title('Predict: '+str(pred[i])); ax.axis('off')
else:
    rgb=np.zeros((4,5,3),dtype=float)
    rgb[:,:,0]=np.clip(np.asarray(pred[:20]).reshape(4,5),0,255)/255
    rgb[:,:,1]=0.45; rgb[:,:,2]=0.35
    plt.imshow(rgb,interpolation='nearest'); plt.title('Predicted red channel')
plt.tight_layout(); plt.savefig('view.png',dpi=120); plt.close('all')
