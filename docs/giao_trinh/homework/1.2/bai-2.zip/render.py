import sys
import json
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
case=Path(sys.argv[1]); data=json.loads((case/'input.json').read_text(encoding='utf-8'))
result=json.loads(Path(sys.argv[2]).read_text(encoding='utf-8'))
kind=data['activity']
if kind=='fit':
    train=pd.read_csv(case/'train.csv'); test=pd.read_csv(case/'test.csv')
    order=np.argsort(test['x'].to_numpy())
    plt.scatter(train['x'],train['label'],s=15,label='Observed train')
    plt.plot(test['x'].to_numpy()[order],np.asarray(result['predictions'])[order],color='red',label='Prediction')
    plt.xlabel('x'); plt.ylabel('y'); plt.legend()
elif kind=='curve':
    plt.plot(result['sizes'],result['train_mae'],'o-',label='Train MAE')
    plt.plot(result['sizes'],result['valid_mae'],'o-',label='Validation MAE')
    plt.xlabel('Number of training examples (NOT epochs)'); plt.ylabel('MAE'); plt.legend()
else:
    q=pd.read_csv(case/'queries.csv')['x'].to_numpy()
    mean=np.asarray(result['mean']); std=np.sqrt(np.asarray(result['variance']))
    plt.plot(q,mean,color='navy',label='Mean prediction')
    plt.fill_between(q,mean-std,mean+std,color='lightblue',label='Across-model std (NOT confidence interval)')
    plt.xlabel('x'); plt.ylabel('Prediction'); plt.legend(fontsize=7)
plt.tight_layout(); plt.savefig('view.png',dpi=120); plt.close('all')
