import json,sys
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
result=json.loads(Path(sys.argv[2]).read_text(encoding='utf-8'))
key=next(key for key in ('validation_mse',) if key in result)
y=result[key]
if y and isinstance(y[0],list):
    plt.imshow(y,aspect='auto'); plt.colorbar()
else: plt.plot(y,marker='.')
plt.title(key+' (specified toy workflow)'); plt.tight_layout(); plt.savefig('view.png'); plt.close('all')
