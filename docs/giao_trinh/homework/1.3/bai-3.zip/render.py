import sys,json
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
case=Path(sys.argv[1]); rows=pd.read_csv(case/'rows.csv',dtype={'group':str})
result=json.loads(Path(sys.argv[2]).read_text(encoding='utf-8'))
if 'assignment' in result:
    rows['bucket']=result['assignment']
    if 'group' in rows:
        table=rows.groupby('bucket')['group'].nunique().reindex(['train','valid','test'])
        table.plot.bar(); plt.ylabel('Distinct groups (each has 3 rows HERE)')
    else:
        table=pd.crosstab(rows['bucket'],rows['label']).reindex(['train','valid','test'])
        table.plot.bar(stacked=True); plt.ylabel('Rows per class')
else:
    plt.scatter(rows['x'],rows['label'],label='Observed label',s=20)
    plt.scatter(rows['x'],result['predictions'],label='OOF prediction',s=8)
    plt.xlabel('x'); plt.ylabel('Class'); plt.legend()
plt.tight_layout(); plt.savefig('view.png',dpi=120); plt.close('all')
