import json,sys
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
result=json.loads(Path(sys.argv[2]).read_text(encoding='utf-8'))
if 'cm' in result:
    plt.imshow(result['cm'],cmap='Blues')
    for i,row in enumerate(result['cm']):
        for j,value in enumerate(row): plt.text(j,i,str(value),ha='center',va='center')
    plt.xticks([0,1],['Pred 0','Pred 1']); plt.yticks([0,1],['True 0','True 1']); plt.title('Rows=true, columns=prediction')
elif 'threshold' in result:
    plt.bar(['Valid F1'],[result['valid_f1']]); plt.ylim(0,1); plt.title('Threshold selected on validation: '+str(result['threshold']))
else:
    losses=[result[key]['log_loss'] for key in ('A','B')]
    plt.bar(['A','B'],losses); plt.ylabel('Log loss (lower better)'); plt.title('Same rank need NOT mean same probabilities')
plt.tight_layout(); plt.savefig('view.png',dpi=120); plt.close('all')
