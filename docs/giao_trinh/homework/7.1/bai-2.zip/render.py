import sys,json,numpy as np
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
result=json.loads(Path(sys.argv[2]).read_text(encoding='utf-8')); power=np.array(result['power']); centers=result['centers']; frequencies=result['frequencies']; plt.imshow(10*np.log10(np.maximum(power,1e-10)),origin='lower',aspect='auto',extent=[centers[0],centers[-1],frequencies[0],frequencies[-1]],cmap='magma'); plt.xlabel('Frame center (s)'); plt.ylabel('Frequency (Hz)'); plt.colorbar(label='dB relative power reference 1'); plt.tight_layout(); plt.savefig('view.png'); plt.close('all')
