import sys,json,wave,numpy as np
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
case=Path(sys.argv[1]); data=json.loads((case/'input.json').read_text(encoding='utf-8'))
with wave.open(str(case/data['file']),'rb') as stream: rate=stream.getframerate(); channels=stream.getnchannels(); frames=stream.getnframes(); x=np.frombuffer(stream.readframes(frames),dtype='<i2').reshape(frames,channels)/32768
result=json.loads(Path(sys.argv[2]).read_text(encoding='utf-8')); t=np.arange(frames)/rate
for c in range(channels): plt.plot(t,x[:,c],label='channel '+str(c),alpha=.7)
plt.plot(t,result['mono'],label='mean downmix',color='black'); plt.xlabel('Time (s)'); plt.ylabel('PCM relative amplitude'); plt.legend(); plt.tight_layout(); plt.savefig('view.png'); plt.close('all')
